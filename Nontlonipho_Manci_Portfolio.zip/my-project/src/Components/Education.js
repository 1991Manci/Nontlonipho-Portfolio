// Import React from the React library
import React from 'react';
 
 // Define a functional component named 'Education'
const Education = () => {
  // The component returns a JSX structure
  return (
    <div className="education">
      <h1>Education</h1>
      <div className="education-item">
        <div className="education-date">2010-2012</div>
        <div className="education-description">
          <p>
            Was doing Matric.
          </p>
        </div>
      </div>
      <div className="education-item">
        <div className="education-date">2015-2017</div>
        <div className="education-description">
          <p>
            Was doing NCV National Certificate in Information Technology and Computer Science Level 4 at Port Elizabeth College.
          </p>
        </div>
      </div>
      <div className="education-item">
        <div className="education-date">2022-2024</div>
        <div className="education-description">
          <p>
            Currently doing Diploma in Information Technology at Belgium Campus.
          </p>
        </div>
      </div>
    </div>
  );
};
 // Export the 'Education' component as the default export of this module
export default Education;
