import React, { useState } from 'react';

const AboutMe = () => {
  const [skills, setSkills] = useState([]);
  const [interests, setInterests] = useState([]);

  const handleSkillChange = (event) => {
    const { value, checked } = event.target;
    setSkills((prevSkills) =>
      checked ? [...prevSkills, value] : prevSkills.filter((skill) => skill !== value)
    );
  };

  const handleInterestChange = (event) => {
    const { value, checked } = event.target;
    setInterests((prevInterests) =>
      checked ? [...prevInterests, value] : prevInterests.filter((interest) => interest !== value)
    );
  };

  return (
    <div className="about">
      <h1>About Me</h1>
      <p>
        Hello! I'm Nontlonipho Manci, dedicated to web programming with a passion for developing innovative solutions. I have a diverse skill set and a range of interests that keep me motivated and driven.
      </p>
      
      <section id='skillsInterests'>
      <div className="checkbox-group left">
      <label htmlFor="interests"><span class="highlight">Interests:</span></label>
        <div id="interests">
          <label>
            <input type="checkbox" name="interests" value="Social-media" onChange={handleInterestChange} />
            Social Media
          </label>
          <label>
            <input type="checkbox" name="interests" value="Reading" onChange={handleInterestChange} />
            Reading
          </label>
          <label>
            <input type="checkbox" name="interests" value="Cooking" onChange={handleInterestChange} />
            Cooking
          </label>
          <label>
            <input type="checkbox" name="interests" value="Traveling" onChange={handleInterestChange} />
            Traveling
          </label>
        </div>
      </div>
      <div className="checkbox-group right">
        <label htmlFor="skills"><span     class="highlight">Skills:</span></label>
        <div id="skills">
          <label>
            <input type="checkbox" name="skills" value="csharp" onChange={handleSkillChange} />
            C#
          </label>
          <label>
            <input type="checkbox" name="skills" value="html" onChange={handleSkillChange} />
            HTML
          </label>
          <label>
            <input type="checkbox" name="skills" value="css" onChange={handleSkillChange} />
            CSS
          </label>
          <label>
            <input type="checkbox" name="skills" value="JavaScript" onChange={handleSkillChange} />
            JavaScript
          </label>
          <label>
            <input type="checkbox" name="skills" value="React.JS" onChange={handleSkillChange} />
            React.JS
          </label>
          <label>
            <input type="checkbox" name="skills" value="Remote work" onChange={handleSkillChange} />
            Remote work
          </label>
          
        </div>
      </div>
      </section>
      <div className="selected-items">
        <h2>Selected Interests</h2>
        <ul>
          {interests.map((interest, index) => (
            <li key={index}>{interest}</li>
          ))}
        </ul>
        <h2>Selected Skills</h2>
        <ul>
          {skills.map((skill, index) => (
            <li key={index}>{skill}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AboutMe;