import React, { useState } from 'react';
 
 
const Contact = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    mobile: '',
    email: '',
    message: ''
  });
 
  const [submittedData, setSubmittedData] = useState(null);
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmittedData(formData);
    // Optionally clear the form fields
    setFormData({
      firstName: '',
      lastName: '',
      mobile: '',
      email: '',
      message: ''
    });
  };
 
  const handleExit = () => {
    setSubmittedData(null);
  };
 
  return (
    <div className="contact">
      <h1>Contact Us</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>First Name:</label>
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Last Name:</label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Mobile Number:</label>
          <input
            type="tel"
            name="mobile"
            value={formData.mobile}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Email Address:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Message:</label>
          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <button type="submit">Submit</button>
      </form>
 
      {submittedData && (
        <div className="submitted-data">
          <h2>Submitted Information</h2>
          <p><strong>First Name:</strong> {submittedData.firstName}</p>
          <p><strong>Last Name:</strong> {submittedData.lastName}</p>
          <p><strong>Mobile Number:</strong> {submittedData.mobile}</p>
          <p><strong>Email Address:</strong> {submittedData.email}</p>
          <p><strong>Message:</strong> {submittedData.message}</p>
          <button onClick={handleExit}>Exit</button>
        </div>
      )}
    </div>
  );
};
 
export default Contact;
