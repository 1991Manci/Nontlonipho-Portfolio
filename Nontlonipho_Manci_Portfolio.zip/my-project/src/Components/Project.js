// Import React and the useState hook from the React library
import React, { useState } from 'react';
 
// Define a functional component named 'Project' 
const Project = () => {
   // Declare a state variable 'expanded' and its setter, initialized to an empty object
  const [expanded, setExpanded] = useState({});
 // Function to handle expanding and collapsing the project details
  const handleExpand = (project) => {
    // Toggle the expanded state for the specific project
    setExpanded((prevExpanded) => ({
      ...prevExpanded,
      [project]: !prevExpanded[project],
    }));
  };
 
  return (
    <div className="projects">
      <h1>Projects</h1>
      <div className="project-row">
        <div className="project-column">
          <img src="../Assets/images/figma.png" alt="figma.png" />
          <p>
            Project 1 description. Figma is a powerful and versatile design tool used for creating user interfaces, wireframes, and prototypes. It is a cloud-based application that allows for real-time collaboration among team members, making it easy to share and receive feedback on designs. With its intuitive interface and comprehensive features, Figma streamlines the design process from conception to completion, making it a favorite among designers and developers alike.
          </p>
          {expanded.project1 && (
            <p className="more-info">
             Figma offers a range of advanced features that enhance the design workflow. Components and styles enable designers to create reusable elements and maintain consistency across projects. Figma's vector networks allow for more flexible and intuitive vector editing compared to traditional design tools. Its robust prototyping capabilities enable designers to create interactive and animated prototypes without needing to write code.
             Figma also integrates seamlessly with other tools and platforms, including Slack, Notion, and JIRA, allowing for a more integrated and efficient workflow. Plugins and widgets extend Figma's functionality, providing additional tools for tasks such as accessibility checking, icon libraries, and design system management. Figma's community is vibrant and active, sharing a wealth of resources such as design templates, UI kits, and educational content.
            </p>
          )}
          <button onClick={() => handleExpand('project1')}>
            {expanded.project1 ? 'Show Less' : 'Show More'}
          </button>
        </div>
        <div className="project-column">
          <img src="../Assets/images/github.png" alt="github.png" />
          <p>
            Project 2 description. GitHub is a web-based platform used for version control and collaborative software development. It is built on Git, a distributed version control system, allowing developers to track changes, manage projects. GitHub provides features such as repositories, pull requests, issues, and project management tools, making it an essential tool for developers to share, review, and deploy code efficiently.user-friendly interface, GitHub is a vital resource for open-source and private projects alike..
          </p>
          {expanded.project2 && (
            <p className="more-info">
              GitHub offers advanced features such as  GitHub Actions, which automate workflows and tasks within the development cycle, enhancing productivity. Developers can utilize GitHub Packages to host and manage project dependencies securely, facilitating smoother project setups and maintenance. GitHub Pages allows users to host static websites directly from a repository, making it ideal for project documentation and personal sites.

GitHub also supports continuous integration and continuous deployment (CI/CD) pipelines, enabling automatic testing and deployment processes that streamline software delivery. Its robust security features, including dependency vulnerability alerts and secret scanning, help maintain the integrity and safety of codebases.

 GitHub fosters a collaborative environment through its social coding features. Developers can follow others, star and watch repositories, and contribute to projects by forking and submitting pull requests. This community-driven aspect encourages knowledge sharing and innovation, making GitHub not just a tool, but a thriving ecosystem for developers worldwide
            </p>
          )}
          <button onClick={() => handleExpand('project2')}>
            {expanded.project2 ? 'Show Less' : 'Show More'}
          </button>
        </div>
        <div className="project-column">
          <img src="../Assets/images/react-1-logo.png" alt="react-1-logo.png" />
          <p>
            Project 3 description. React.js is a popular JavaScript library for building user interfaces, particularly for single-page applications. Developed and maintained by Facebook, React allows developers to create large web applications that can change data, without reloading the page. Its component-based architecture encourages the creation of reusable UI components, which simplifies the development process and makes code more manageable.
          </p>
          {expanded.project3 && (
            <p className="more-info">
              React leverages a virtual DOM to optimize rendering performance, ensuring that updates are efficient and fast. This makes it an excellent choice for applications requiring dynamic and responsive user interfaces. With JSX, a syntax extension that allows HTML to be written within JavaScript, React makes it easy to understand and write components. Additionally, React's ecosystem includes powerful tools like React Router for navigation and Redux for state management, further enhancing its capability for building complex applications.
              React's declarative nature makes it straightforward to design interactive UIs. When data changes, React efficiently updates and renders the necessary components, making the code more predictable and easier to debug. The strong community support, extensive documentation, and a vast array of libraries and tools available make React a preferred choice for modern web development.
            </p>
          )}
          <button onClick={() => handleExpand('project3')}>
            {expanded.project3 ? 'Show Less' : 'Show More'}
          </button>
        </div>
      </div>
    </div>
  );
};
// Export the 'Project' component as the default export of this module 
export default Project;
