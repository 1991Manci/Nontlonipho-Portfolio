import React, { useState } from 'react';
 
 
const Services = () => {
  const [expanded, setExpanded] = useState(null);
 
  const handleExpand = (service) => {
    setExpanded(expanded === service ? null : service);
  };
  <h1>Service</h1>
  return (
 
    <div className="service">
       
      <div className="service-column">
        <img src="../Assets/images/web-devel-important.png" alt="web-devel-important.png" />
        <h2>Web Development</h2>
        <p>
          Web development involves building and maintaining websites. It's the work that happens behind the scenes to make a website look great, work fast, and perform well with a seamless user experience.
        </p>
        <button onClick={() => handleExpand('web-development')}>
          {expanded === 'web-development' ? 'Show Less' : 'Read More'}
        </button>
        {expanded === 'web-development' && (
          <div className="expanded-content">
            <p>
              More detailed information about web development, including the latest technologies, frameworks, and best practices.
            </p>
          </div>
        )}
      </div>
 
      <div className="service-column">
        <img src="../Assets/images/digitalmarketing.png" alt="digitalmarketing.png" />
        <h2>Digital Marketing</h2>
        <p>
          Digital marketing encompasses all marketing efforts that use an electronic device or the internet. Businesses leverage digital channels such as search engines, social media, email, and other websites to connect with current and prospective customers.
        </p>
        <button onClick={() => handleExpand('digital-marketing')}>
          {expanded === 'digital-marketing' ? 'Show Less' : 'Read More'}
        </button>
        {expanded === 'digital-marketing' && (
          <div className="expanded-content">
            <p>
              More detailed information about digital marketing strategies, tools, and case studies of successful campaigns.
            </p>
          </div>
        )}
      </div>
 
      <div className="service-column">
        <img src="../Assets/images/ux-ui.jpeg" alt="ux-ui.jpeg" />
        <h2>UX-UI Designer</h2>
        <p>
          UX/UI design involves planning and iterating a site's structure and layout. Once the proper information architecture is in place, designers create wireframes to layout the visual structure of the interface.
        </p>
        <button onClick={() => handleExpand('ux-ui-designer')}>
          {expanded === 'ux-ui-designer' ? 'Show Less' : 'Read More'}
        </button>
        {expanded === 'ux-ui-designer' && (
          <div className="expanded-content">
            <p>
              More detailed information about UX/UI design principles, tools, and examples of well-designed interfaces.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
export default Services;
