import React from 'react';
import '@fortawesome/fontawesome-free/css/all.min.css';
const Home = () => {
  const handleDownload = () => {
    // The URL to your CV file
    const cvUrl = '../Assets/images/Nontlonipho_Manci(IT specialist_software Dev)-merged (2).pdf';
   
    // Creating an anchor element and programmatically clicking it to trigger the download
    const link = document.createElement('a');
    link.href = cvUrl;
    link.download = 'My_CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="home">
       <div className="profile-picture">
<img src="../Assets/images/ntloni.png" alt="ntloni.png" />
      </div>
      <h1>Hello it's Me</h1>
      <h3>Welcome to Nontlonipho Manci Portfolio</h3>
      <p>
       Front-end developers play a crucial role in creating engaging and user-friendly web experiences by combining design and technological skills to build effective interfaces.
      </p>
      <br/>
      <div className="social-media-icons">
        <a href="https://wa.me/yourphonenumber" target="_blank" rel="noopener noreferrer">
          <i className="fab fa-whatsapp"></i>
        </a>
        <a href="https://www.instagram.com/yourusername" target="_blank" rel="noopener noreferrer">
          <i className="fab fa-instagram"></i>
        </a>
        <a href="https://www.facebook.com/yourusername" target="_blank" rel="noopener noreferrer">
          <i className="fab fa-facebook"></i>
        </a>
        <a href="https://twitter.com/yourusername" target="_blank" rel="noopener noreferrer">
          <i className="fab fa-twitter"></i>
        </a>
      </div>
      <button onClick={handleDownload}>Download CV</button>
    </div>
  );
};

export default Home;
