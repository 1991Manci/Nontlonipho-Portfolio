import React from 'react';
 
 
const Experience = () => {
  return (
    <div className="experience">
      <div className="left-column">
       
        <div className="profile-picture">
 
          <img src="../Assets/images/ntloni.png" alt="ntloni.png"/>
          </div>
        <h2>Personal Details</h2>
        <h3>Name: Nontlonipho Manci</h3>
        <p>Email: ntlonientonga@gmail.com</p>
        <p>Number: 0656316827</p>
        <h3>Languages</h3>
        <ul>
          <li>Xhosa</li>
          <li>English</li>
          <li>Zulu</li>
        </ul>
        <h3>Frameworks & Tools</h3>
        <ul>
          <li>
            <input type="checkbox" checked readOnly /> React.js
          </li>
          <li>
            <input type="checkbox" checked readOnly /> Github
          </li>
          <li>
            <input type="checkbox" checked readOnly /> Figma
          </li>
          <li>
            <input type="checkbox" checked readOnly /> Netflix
          </li>
        </ul>
      </div>
      <div className="right-column">
        <h2>Profile</h2>
        <hr />
        <p>
          I am Nontlonipho Manci, a software developer with expertise in web programming and UI/UX design using Figma. I possess the skills to manage and upload content to Netflix's platforms.
        </p>
        <h3>Proficient Experience</h3>
        <hr />
        <h4>Software Developer (2021 November 02)</h4>
       
        <p>
          A software developer specializing in salon websites plays a crucial role in helping salon businesses establish a strong online presence and attract customers in today's digital age. At MICSETA as an intern.
        </p>
        <hr />
        <h4>Teaching (2020 January 19)</h4>
        <p>
          My role as an assistant teacher for mathematics in grades 4 to 6 involved providing essential support to the lead teacher and helping students build a strong foundation in mathematics through personalized instruction and targeted interventions.
        </p>
        <hr />
    <h3>References</h3>
    <hr />
    <p>Reference 1:Miss Zanele Mgoqi - zmgoqi307@gmail.com</p>
    <p>Reference 2:Mrs Shakifa Salie - ficka@webmail.co.za</p>
    <p>Reference 3:Mr Theodorus Kritzinger  - Kritzinger.t@belgiumcampus.co.za</p>
    <p>Reference 4:Mrs Adonis   - 0721173575/0415857771</p>
      </div>
    </div>
  );
};
export default Experience;