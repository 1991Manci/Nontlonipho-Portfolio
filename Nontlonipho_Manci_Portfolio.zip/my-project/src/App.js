import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './Components/Home';
import AboutMe from './Components/AboutMe';
import Services from './Components/Services';
import Project from './Components/Project';
import Education from './Components/Education';
import Experience from './Components/Experience';
import Contact from './Components/Contact';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        
        <nav className="navbar">
          <Link to="/">Home</Link>
          <Link to="/about-me">About Me</Link>
          <Link to="/services">Services</Link>
          <Link to="/project">Project</Link>
          <Link to="/education">Education</Link>
          <Link to="/experience">Experience</Link>
          <Link to="/contact">Contact</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about-me" element={<AboutMe />} />
          <Route path="/services" element={<Services />} />
          <Route path="/project" element={<Project />} />
          <Route path="/education" element={<Education />} />
          <Route path="/experience" element={<Experience />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
